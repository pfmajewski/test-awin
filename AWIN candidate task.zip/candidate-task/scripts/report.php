<?php 

//TODO print formatted report

foreach ($merchant->getTransactions() as $transaction) {
    
}