<?php

class Merchant
{
    public function getTransactions()
    {
        
    }
}